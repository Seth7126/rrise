/*

The content of this file includes portions of the AUDIOKINETIC Wwise Technology
released in source code form as part of the SDK installer package.

Commercial License Usage

Licensees holding valid commercial licenses to the AUDIOKINETIC Wwise Technology
may use this file in accordance with the end user license agreement provided 
with the software or, alternatively, in accordance with the terms contained in a
written agreement between you and Audiokinetic Inc.

Apache License Usage

Alternatively, this file may be used under the Apache License, Version 2.0 (the 
"Apache License"); you may not use this file except in compliance with the 
Apache License. You may obtain a copy of the Apache License at 
http://www.apache.org/licenses/LICENSE-2.0.

Unless required by applicable law or agreed to in writing, software distributed
under the Apache License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES
OR CONDITIONS OF ANY KIND, either express or implied. See the Apache License for
the specific language governing permissions and limitations under the License.

  Copyright (c) 2026 Audiokinetic Inc.

*/
public class ak
{
	public class soundengine
	{
		/// <summary>Executes an action on all nodes that are referenced in the specified event in a Play action. See <tt>AK::SoundEngine::ExecuteActionOnEvent</tt>.</summary>
		public const string executeActionOnEvent = "ak.soundengine.executeActionOnEvent";
		/// <summary>Gets the current state of a State Group. When using setState just prior to getState, allow a brief delay (no more than 10ms) for the information to update in the sound engine.</summary>
		public const string getState = "ak.soundengine.getState";
		/// <summary>Gets the current state of a Switch Group for a given Game Object.</summary>
		public const string getSwitch = "ak.soundengine.getSwitch";
		/// <summary>Load a SoundBank. See <tt>AK::SoundEngine::LoadBank</tt>.</summary>
		public const string loadBank = "ak.soundengine.loadBank";
		/// <summary>Asynchronously post an Event to the sound engine (by event ID). See <tt>AK::SoundEngine::PostEvent</tt>.</summary>
		public const string postEvent = "ak.soundengine.postEvent";
		/// <summary>Display a message in the Profiler's Capture Log view.</summary>
		public const string postMsgMonitor = "ak.soundengine.postMsgMonitor";
		/// <summary>Posts the specified Trigger. See <tt>AK::SoundEngine::PostTrigger</tt>.</summary>
		public const string postTrigger = "ak.soundengine.postTrigger";
		/// <summary>Register a game object. Registering a game object twice does nothing. Unregistering it once unregisters it no matter how many times it has been registered. See <tt>AK::SoundEngine::RegisterGameObj</tt>.</summary>
		public const string registerGameObj = "ak.soundengine.registerGameObj";
		/// <summary>Resets the value of a real-time parameter control to its default value, as specified in the Wwise project. See <tt>AK::SoundEngine::ResetRTPCValue</tt>.</summary>
		public const string resetRTPCValue = "ak.soundengine.resetRTPCValue";
		/// <summary>Seeks inside all playing objects that are referenced in Play Actions of the specified Event. See <tt>AK::SoundEngine::SeekOnEvent</tt>.</summary>
		public const string seekOnEvent = "ak.soundengine.seekOnEvent";
		/// <summary>Sets the default active listeners for all subsequent game objects that are registered. See <tt>AK::SoundEngine::SetDefaultListeners</tt>.</summary>
		public const string setDefaultListeners = "ak.soundengine.setDefaultListeners";
		/// <summary>Sets the Auxiliary Busses to route the specified game object. See <tt>AK::SoundEngine::SetGameObjectAuxSendValues</tt>.</summary>
		public const string setGameObjectAuxSendValues = "ak.soundengine.setGameObjectAuxSendValues";
		/// <summary>Set the output bus volume (direct) to be used for the specified game object. See <tt>AK::SoundEngine::SetGameObjectOutputBusVolume</tt>.</summary>
		public const string setGameObjectOutputBusVolume = "ak.soundengine.setGameObjectOutputBusVolume";
		/// <summary>Sets a listener's spatialization parameters. This lets you define listener-specific volume offsets for each audio channel. See <tt>AK::SoundEngine::SetListenerSpatialization</tt>.</summary>
		public const string setListenerSpatialization = "ak.soundengine.setListenerSpatialization";
		/// <summary>Sets a single game object's active listeners. By default, all new game objects have no listeners active, but this behavior can be overridden with <tt>SetDefaultListeners()</tt>. Inactive listeners are not computed. See <tt>AK::SoundEngine::SetListeners</tt>.</summary>
		public const string setListeners = "ak.soundengine.setListeners";
		/// <summary>Sets multiple positions for a single game object. Setting multiple positions for a single game object is a way to simulate multiple emission sources while using the resources of only one voice. This can be used to simulate wall openings, area sounds, or multiple objects emitting the same sound in the same area. See <tt>AK::SoundEngine::SetMultiplePositions</tt>.</summary>
		public const string setMultiplePositions = "ak.soundengine.setMultiplePositions";
		/// <summary>Set a game object's obstruction and occlusion levels. This function is used to affect how an object should be heard by a specific listener. See <tt>AK::SoundEngine::SetObjectObstructionAndOcclusion</tt>.</summary>
		public const string setObjectObstructionAndOcclusion = "ak.soundengine.setObjectObstructionAndOcclusion";
		/// <summary>Sets the position of a game object. See <tt>AK::SoundEngine::SetPosition</tt>.</summary>
		public const string setPosition = "ak.soundengine.setPosition";
		/// <summary>Sets the value of a Game Parameter for real-time parameter control. See <tt>AK::SoundEngine::SetRTPCValue</tt>.</summary>
		public const string setRTPCValue = "ak.soundengine.setRTPCValue";
		/// <summary>Sets the scaling factor of a game object. You can modify the attenuation computations on this game object to simulate sounds with a larger or smaller affected areas. See <tt>AK::SoundEngine::SetScalingFactor</tt>.</summary>
		public const string setScalingFactor = "ak.soundengine.setScalingFactor";
		/// <summary>Sets the State of a State Group. See <tt>AK::SoundEngine::SetState</tt>.</summary>
		public const string setState = "ak.soundengine.setState";
		/// <summary>Sets the State of a Switch Group. See <tt>AK::SoundEngine::SetSwitch</tt>.</summary>
		public const string setSwitch = "ak.soundengine.setSwitch";
		/// <summary>Stop playing the current content associated to the specified game object ID. If no game object is specified, all sounds are stopped. See <tt>AK::SoundEngine::StopAll</tt>.</summary>
		public const string stopAll = "ak.soundengine.stopAll";
		/// <summary>Stops the current content, associated to the specified playing ID, from playing. See <tt>AK::SoundEngine::StopPlayingID</tt>.</summary>
		public const string stopPlayingID = "ak.soundengine.stopPlayingID";
		/// <summary>Unload a SoundBank. See <tt>AK::SoundEngine::UnloadBank</tt>.</summary>
		public const string unloadBank = "ak.soundengine.unloadBank";
		/// <summary>Unregisters a game object. Registering a game object twice does nothing. Unregistering it once unregisters it no matter how many times it has been registered. Unregistering a game object while it is in use is allowed, but the control over the parameters of this game object is lost. For example, say a sound associated with this game object is a 3D moving sound. It stops moving when the game object is unregistered, and there is no way to regain control over the game object. See <tt>AK::SoundEngine::UnregisterGameObj</tt>.</summary>
		public const string unregisterGameObj = "ak.soundengine.unregisterGameObj";
	}
	public class wwise
	{
		public class cli
		{
			/// <summary>Adds a new platform to a project. The platform must not already exist.</summary>
			public const string addNewPlatform = "ak.wwise.cli.addNewPlatform";
			/// <summary>External sources conversion. Converts the external sources files for the specified project. Optionally, additional WSOURCES can be specified. External Sources are a special type of source that you can put in a sound object in Wwise. It indicates that the real sound data will be provided at runtime. While external source conversion can be triggered by SoundBank generation, this operation can be used to process sources not contained in the Wwise Project. See \ref integrating_external_sources.</summary>
			public const string convertExternalSource = "ak.wwise.cli.convertExternalSource";
			/// <summary>Creates a blank new project. The project must not already exist. If the directory does not exist, it is created.</summary>
			public const string createNewProject = "ak.wwise.cli.createNewProject";
			/// <summary>Dump the objects model of a project as a JSON file.</summary>
			public const string dumpObjects = "ak.wwise.cli.dumpObjects";
			/// <summary>Execute a Lua script. Optionally, specify additional Lua search paths, additional modules, and additional Lua scripts to load prior to the main script. The script can return a value. All arguments will be passed to the Lua script in the "wa_args" global variable.</summary>
			public const string executeLuaScript = "ak.wwise.cli.executeLuaScript";
			/// <summary>SoundBank generation. SoundBank generation is performed according to the settings stored in the project. User SoundBanks Settings are normally ignored when SoundBank generation is launched from the command line. However, when using the Source Control for generated SoundBanks, the User Project Settings are loaded for the Source Control settings. Also, some of these settings can be overridden from the command line.</summary>
			public const string generateSoundbank = "ak.wwise.cli.generateSoundbank";
			/// <summary>Migrates and saves the project.</summary>
			public const string migrate = "ak.wwise.cli.migrate";
			/// <summary>Moves the project's media IDs from its work units (.wwu) to a single file, <project-name>.mediaid.  This command forces a save of all the project's work units.</summary>
			public const string moveMediaIdsToSingleFile = "ak.wwise.cli.moveMediaIdsToSingleFile";
			/// <summary>Moves the project's media IDs from a single xml file <project-name>.mediaid to its work units (.wwu).  This command forces a save of all the project's work units.</summary>
			public const string moveMediaIdsToWorkUnits = "ak.wwise.cli.moveMediaIdsToWorkUnits";
			/// <summary>Imports a tab-delimited file to create and modify different object hierarchies. The project is automatically migrated (if required). It is also automatically saved following the import.</summary>
			public const string tabDelimitedImport = "ak.wwise.cli.tabDelimitedImport";
			/// <summary>Loads the project and updates the contents of <project-name>.mediaid, if it exists.</summary>
			public const string updateMediaIdsInSingleFile = "ak.wwise.cli.updateMediaIdsInSingleFile";
			/// <summary>Loads the project and does nothing else. This is useful to see the log for verification purposes without actually migrating and saving.</summary>
			public const string verify = "ak.wwise.cli.verify";
			/// <summary>Starts a command-line Wwise Authoring API server, to which client applications, using the Wwise Authoring API, can connect.</summary>
			public const string waapiServer = "ak.wwise.cli.waapiServer";
		}
		public class console
		{
			public class project
			{
				/// <summary>Closes the current project. This operation is synchronous.</summary>
				public const string close = "ak.wwise.console.project.close";
				/// <summary>Creates, saves and opens new empty project, specified by path and platform. The project has no factory setting WorkUnit. This operation is synchronous.</summary>
				public const string create = "ak.wwise.console.project.create";
				/// <summary>Opens a project, specified by path. This operation is synchronous.</summary>
				public const string open = "ak.wwise.console.project.open";
			}
		}
		public class core
		{
			public class audio
			{
				/// <summary>Creates a converted audio file. When errors occur, this function returns a list of messages with corresponding levels of severity.</summary>
				public const string convert = "ak.wwise.core.audio.convert";
				/// <summary>Creates Wwise objects and imports audio files. This function does not return an error when something fails during the import process, please see the log for the result of each import command. This function uses the same importation processor available through the Tab Delimited import in the Audio File Importer. The function returns an array of all objects created, replaced or re-used. Use the options to specify how the objects are returned. For more information, see \ref waapi_import.</summary>
				public const string import = "ak.wwise.core.audio.import";
				/// <summary>Scripted object creation and audio file import from a tab-delimited file.</summary>
				public const string importTabDelimited = "ak.wwise.core.audio.importTabDelimited";
				/// <summary>Sent at the end of an import operation.</summary>
				public const string imported = "ak.wwise.core.audio.imported";
				/// <summary>Mutes an object.</summary>
				public const string mute = "ak.wwise.core.audio.mute";
				/// <summary>Unmute all muted objects.</summary>
				public const string resetMute = "ak.wwise.core.audio.resetMute";
				/// <summary>Unsolo all soloed objects.</summary>
				public const string resetSolo = "ak.wwise.core.audio.resetSolo";
				/// <summary>Changes the plug-in to use for audio file conversion.</summary>
				public const string setConversionPlugin = "ak.wwise.core.audio.setConversionPlugin";
				/// <summary>Solos an object.</summary>
				public const string solo = "ak.wwise.core.audio.solo";
			}
			public class audioSourcePeaks
			{
				/// <summary>Gets the min/max peak pairs, in the given region of an audio source, as a collection of binary strings (one per channel). The strings are base-64 encoded, 16-bit signed int arrays, with min and max values being interleaved. If getCrossChannelPeaks is true, only one binary string represents the peaks across all channels globally.</summary>
				public const string getMinMaxPeaksInRegion = "ak.wwise.core.audioSourcePeaks.getMinMaxPeaksInRegion";
				/// <summary>Gets the min/max peak pairs in the entire trimmed region of an audio source, for each channel, as an array of binary strings (one per channel). The strings are base-64 encoded, 16-bit signed int arrays, with min and max values being interleaved. If getCrossChannelPeaks is true, there is only one binary string representing peaks across all channels globally.</summary>
				public const string getMinMaxPeaksInTrimmedRegion = "ak.wwise.core.audioSourcePeaks.getMinMaxPeaksInTrimmedRegion";
			}
			public class blendContainer
			{
				/// <summary>Adds a new assignment to a Blend Track. Equivalent to performing a drag-and-drop operation in the Blend Tracks Editor.</summary>
				public const string addAssignment = "ak.wwise.core.blendContainer.addAssignment";
				/// <summary>Adds a new Blend Track to a Blend Container. Equivalent to clicking New Blend Track in the Blend Track Editor. To get the list of Blend Tracks, use the function ak.wwise.core.object.get with {return = "blendTracks"}.</summary>
				public const string addTrack = "ak.wwise.core.blendContainer.addTrack";
				/// <summary>Returns a list of a Blend Track assignments.</summary>
				public const string getAssignments = "ak.wwise.core.blendContainer.getAssignments";
				/// <summary>Removes an assignment from a Blend Track. Equivalent to deleting an entry in the Blend Tracks Editor.</summary>
				public const string removeAssignment = "ak.wwise.core.blendContainer.removeAssignment";
			}
			/// <summary>Execute Lua code from a file path (using \c luaScript) or directly as a string (using \c luaString). Optionally, specify additional Lua search paths, additional modules, and additional Lua scripts to load prior to the main script. The script can return a value, which can be any of the Lua types, including tables. All WAAPI arguments will be passed to the Lua script in the \c wa_args global variable, as a Lua table. Define your own key-values in the WAAPI arguments and access them from the Lua code. Use \c wa_call to call a WAAPI function from the Lua script. See \ref ak_wwise_waapi_getfunctions and \ref ak_wwise_waapi_getschema to learn more about the functions available and their schema before using \c wa_call. If both \c luaScript and \c luaString are provided, the script file will be executed first, followed by the string code. Note that the Lua environment is reset at each call to this function.</summary>
			public const string executeLuaScript = "ak.wwise.core.executeLuaScript";
			public class gameParameter
			{
				/// <summary>Sets the Min and Max properties on a Game Parameter. Modifies the RTPC curves and blend tracks that use this Game Parameter for their X axis.</summary>
				public const string setRange = "ak.wwise.core.gameParameter.setRange";
			}
			/// <summary>Retrieve global Wwise information.</summary>
			public const string getInfo = "ak.wwise.core.getInfo";
			/// <summary>Retrieve information about the current project opened, including platforms, languages and project directories.</summary>
			public const string getProjectInfo = "ak.wwise.core.getProjectInfo";
			public class log
			{
				/// <summary>Adds a new item to the logs on the specified channel.</summary>
				public const string addItem = "ak.wwise.core.log.addItem";
				/// <summary>Clears the logs on the specified channel.</summary>
				public const string clear = "ak.wwise.core.log.clear";
				/// <summary>Retrieves the latest log for a specific channel. See \ref ak_wwise_core_log_itemadded to be notified when an item is added to the log. The log is empty when used in WwiseConsole.</summary>
				public const string get = "ak.wwise.core.log.get";
				/// <summary>Sent when an item is added to the log. This could be used to retrieve items added to the SoundBank generation log. To retrieve the complete log, see \ref ak_wwise_core_log_get.</summary>
				public const string itemAdded = "ak.wwise.core.log.itemAdded";
			}
			public class mediaPool
			{
				/// <summary>Retrieve files from Media Pool. Use the return options to specify which properties of the files to return.</summary>
				public const string get = "ak.wwise.core.mediaPool.get";
				/// <summary>Retrieve all fields present in the Media Pool. You can then use the fields to query the Media Pool. The Media Pool discovers some fields when it scans audio files. Others, such as WAV fields, are always available.</summary>
				public const string getFields = "ak.wwise.core.mediaPool.getFields";
			}
			public class @object
			{
				/// <summary>Sent when an attenuation curve is changed.</summary>
				public const string attenuationCurveChanged = "ak.wwise.core.object.attenuationCurveChanged";
				/// <summary>Sent when an attenuation curve's link/unlink is changed.</summary>
				public const string attenuationCurveLinkChanged = "ak.wwise.core.object.attenuationCurveLinkChanged";
				/// <summary>Sent when an object is added as a child to another object. See \ref ak_wwise_core_object_structurechanged to receive changes in batch.</summary>
				public const string childAdded = "ak.wwise.core.object.childAdded";
				/// <summary>Sent when an object is removed from the children of another object. See \ref ak_wwise_core_object_structurechanged to receive changes in batch.</summary>
				public const string childRemoved = "ak.wwise.core.object.childRemoved";
				/// <summary>Copies an object to the given parent. Note that if a Work Unit is copied, the operation cannot be undone and the project will be saved.</summary>
				public const string copy = "ak.wwise.core.object.copy";
				/// <summary>Creates an object of type 'type', as a child of 'parent'. See \ref waapi_import for more information about creating objects. Also see \ref ak_wwise_core_audio_import to import audio files to Wwise. To create Effect or Source plug-ins, use \ref ak_wwise_core_object_set, and see \ref wobjects_index for the classId.</summary>
				public const string create = "ak.wwise.core.object.create";
				/// <summary>Sent when an object is created. See \ref ak_wwise_core_object_structurechanged to receive changes in batch.</summary>
				public const string created = "ak.wwise.core.object.created";
				/// <summary>Sent when one or many curves are changed.</summary>
				public const string curveChanged = "ak.wwise.core.object.curveChanged";
				/// <summary>Deletes the specified object. Note that if a Work Unit is deleted, the operation cannot be undone and the project will be saved.</summary>
				public const string delete = "ak.wwise.core.object.delete";
				/// <summary>Compares properties and lists of the source object with those in the target object.</summary>
				public const string diff = "ak.wwise.core.object.diff";
				/// <summary>Performs a query and returns the data, as specified in the options, for each object in the query result. The query can specify either a 'waql' argument or a 'from' argument with an optional 'transform' argument. See \ref waql_introduction or \ref waapi_query for more information. See \ref waapi_query_return to learn about options.</summary>
				public const string get = "ak.wwise.core.object.get";
				/// <summary>Gets the specified attenuation curve for a given attenuation object.</summary>
				public const string getAttenuationCurve = "ak.wwise.core.object.getAttenuationCurve";
				/// <summary>Retrieves the list of property and reference names for an object.</summary>
				public const string getPropertyAndReferenceNames = "ak.wwise.core.object.getPropertyAndReferenceNames";
				/// <summary>Retrieves information about an object property. Note that this function does not return the value of a property. To retrieve the value of a property, see \ref ak_wwise_core_object_get and \ref waapi_query_return.</summary>
				public const string getPropertyInfo = "ak.wwise.core.object.getPropertyInfo";
				/// <summary>Retrieves the list of property and reference names for an object.</summary>
				public const string getPropertyNames = "ak.wwise.core.object.getPropertyNames";
				/// <summary>Retrieves the list of all object types registered in Wwise's object model. This function returns the equivalent of \ref wobjects_index .</summary>
				public const string getTypes = "ak.wwise.core.object.getTypes";
				/// <summary>Indicates whether a property, reference, or object list is bound to a particular platform or to all platforms.</summary>
				public const string isLinked = "ak.wwise.core.object.isLinked";
				/// <summary>Returns true if a property is enabled based on the values of the properties it depends on.</summary>
				public const string isPropertyEnabled = "ak.wwise.core.object.isPropertyEnabled";
				/// <summary>Moves an object to the given parent. Returns the moved object.</summary>
				public const string move = "ak.wwise.core.object.move";
				/// <summary>Sent when an object is renamed. Publishes the renamed object. See \ref ak_wwise_core_object_structurechanged to receive changes in batch.</summary>
				public const string nameChanged = "ak.wwise.core.object.nameChanged";
				/// <summary>Sent when the object's notes are changed.</summary>
				public const string notesChanged = "ak.wwise.core.object.notesChanged";
				/// <summary>Pastes properties, references and lists from one object to any number of target objects. Only those properties, references and lists which differ between source and target are pasted. See \ref wobjects_index for more information on the properties, references and lists available on each object type.</summary>
				public const string pasteProperties = "ak.wwise.core.object.pasteProperties";
				/// <summary>Sent following an object's deletion. See \ref ak_wwise_core_object_structurechanged to receive changes in batch.</summary>
				public const string postDeleted = "ak.wwise.core.object.postDeleted";
				/// <summary>Sent prior to an object's deletion. See \ref ak_wwise_core_object_structurechanged to receive changes in batch.</summary>
				public const string preDeleted = "ak.wwise.core.object.preDeleted";
				/// <summary>Sent when the watched property of an object changes.</summary>
				public const string propertyChanged = "ak.wwise.core.object.propertyChanged";
				/// <summary>Sent when an object reference is changed.</summary>
				public const string referenceChanged = "ak.wwise.core.object.referenceChanged";
				/// <summary>Allows for batch processing of the following operations: Object creation in a child hierarchy, Object creation in a list, Setting name, notes, properties and references. See \ref waapi_import for more information about creating objects. Also see \ref ak_wwise_core_audio_import to import audio files to Wwise.</summary>
				public const string set = "ak.wwise.core.object.set";
				/// <summary>Sets the specified attenuation curve for a given attenuation object.</summary>
				public const string setAttenuationCurve = "ak.wwise.core.object.setAttenuationCurve";
				/// <summary>Link or unlink a property/reference or object list to a particular platform.</summary>
				public const string setLinked = "ak.wwise.core.object.setLinked";
				/// <summary>Renames an object.</summary>
				public const string setName = "ak.wwise.core.object.setName";
				/// <summary>Sets the object's notes.</summary>
				public const string setNotes = "ak.wwise.core.object.setNotes";
				/// <summary>Sets a property value of an object for a specific platform. See \ref wobjects_index for more information on the properties available on each object type. See \ref ak_wwise_core_object_setreference to set a reference to an object. See \ref ak_wwise_core_object_get to obtain the value of a property for an object.</summary>
				public const string setProperty = "ak.wwise.core.object.setProperty";
				/// <summary>Sets the randomizer values of a property of an object for a specific platform. See \ref wobjects_index for more information on the properties available on each object type.</summary>
				public const string setRandomizer = "ak.wwise.core.object.setRandomizer";
				/// <summary>Sets an object's reference value. See \ref wobjects_index for more information on the references available on each object type.</summary>
				public const string setReference = "ak.wwise.core.object.setReference";
				/// <summary>Sets the State Group objects associated with an object. Note, this will remove any previously associated State Group.</summary>
				public const string setStateGroups = "ak.wwise.core.object.setStateGroups";
				/// <summary>Set the state properties of an object. Note, this will remove any previous state property, including the default ones.</summary>
				public const string setStateProperties = "ak.wwise.core.object.setStateProperties";
				/// <summary>Sent when the project structure changes. Publishes a summary of the changes. The publication is sent after the undo stack is modified. The changes are grouped in batch and redundant changes are collapsed.</summary>
				public const string structureChanged = "ak.wwise.core.object.structureChanged";
			}
			/// <summary>Verify if WAAPI is currently available.</summary>
			public const string ping = "ak.wwise.core.ping";
			public class plugin
			{
				/// <summary>Retrieves the list of all object types registered in Wwise's object model. This function returns the equivalent of \ref wobjects_index .</summary>
				public const string getList = "ak.wwise.core.plugin.getList";
				/// <summary>Retrieves the list of property and reference names for an object.</summary>
				public const string getProperties = "ak.wwise.core.plugin.getProperties";
				/// <summary>Retrieves information about an object property. Note that this function does not return the value of a property. To retrieve the value of a property, see \ref ak_wwise_core_object_get and \ref waapi_query_return.</summary>
				public const string getProperty = "ak.wwise.core.plugin.getProperty";
			}
			public class profiler
			{
				public class captureLog
				{
					/// <summary>Sent when a new entry is added to the capture log. Note that all entries are being sent. No filtering is applied as opposed to the Capture Log view.</summary>
					public const string itemAdded = "ak.wwise.core.profiler.captureLog.itemAdded";
				}
				/// <summary>Specifies the type of data you want to capture. Overrides the user's profiler settings.</summary>
				public const string enableProfilerData = "ak.wwise.core.profiler.enableProfilerData";
				/// <summary>Sent when a game object has been registered.</summary>
				public const string gameObjectRegistered = "ak.wwise.core.profiler.gameObjectRegistered";
				/// <summary>Sent when the game objects have been reset, such as closing a connection to a game while profiling.</summary>
				public const string gameObjectReset = "ak.wwise.core.profiler.gameObjectReset";
				/// <summary>Sent when a game object has been unregistered.</summary>
				public const string gameObjectUnregistered = "ak.wwise.core.profiler.gameObjectUnregistered";
				/// <summary>Retrieves the Audio Objects at a specific profiler capture time.</summary>
				public const string getAudioObjects = "ak.wwise.core.profiler.getAudioObjects";
				/// <summary>Retrieves the busses at a specific profiler capture time.</summary>
				public const string getBusses = "ak.wwise.core.profiler.getBusses";
				/// <summary>Retrieves CPU usage statistics at a specific profiler capture time. This data can also be found in the Advanced Profiler, under the CPU tab. To ensure the CPU data is received, see \ref ak_wwise_core_profiler_enableprofilerdata. The returned data includes "Inclusive" and "Exclusive" values, where "Inclusive" refers to the time spent in the element plus the time spent in any called elements, and "Exclusive" values pertain to execution only within the element itself.</summary>
				public const string getCpuUsage = "ak.wwise.core.profiler.getCpuUsage";
				/// <summary>Returns the current time of the specified profiler cursor, in milliseconds.</summary>
				public const string getCursorTime = "ak.wwise.core.profiler.getCursorTime";
				/// <summary>Retrieves the game objects at a specific profiler capture time.</summary>
				public const string getGameObjects = "ak.wwise.core.profiler.getGameObjects";
				/// <summary>Retrieves the loaded media at a specific profiler capture time. This data can also be found in the Advanced Profiler, under the Loaded Media tab. To ensure the Loaded Media data is received, see \ref ak_wwise_core_profiler_enableprofilerdata.</summary>
				public const string getLoadedMedia = "ak.wwise.core.profiler.getLoadedMedia";
				/// <summary>Retrieves the Meter data for all registered busses, aux busses and devices. Only the Main Audio Bus is registered by default. Use \ref ak_wwise_core_profiler_registermeter for other busses, before retrieval of the meter data.</summary>
				public const string getMeters = "ak.wwise.core.profiler.getMeters";
				/// <summary>Retrieves the Performance Monitor statistics at a specific profiler capture time. See \ref globalcountersids for the available counters.</summary>
				public const string getPerformanceMonitor = "ak.wwise.core.profiler.getPerformanceMonitor";
				/// <summary>Retrieves active RTPCs at a specific profiler capture time.</summary>
				public const string getRTPCs = "ak.wwise.core.profiler.getRTPCs";
				/// <summary>Retrieves the streaming media at a specific profiler capture time. This data can also be found in the Advanced Profiler, under the Streams tab. To ensure the Streams data is received, see \ref ak_wwise_core_profiler_enableprofilerdata.</summary>
				public const string getStreamedMedia = "ak.wwise.core.profiler.getStreamedMedia";
				/// <summary>Retrieves all parameters affecting voice volume, highpass and lowpass for a voice path, resolved from pipeline IDs.</summary>
				public const string getVoiceContributions = "ak.wwise.core.profiler.getVoiceContributions";
				/// <summary>Retrieves the voices at a specific profiler capture time.</summary>
				public const string getVoices = "ak.wwise.core.profiler.getVoices";
				/// <summary>Moves the user time cursor of the profiler to a specific position (first, last, next, previous), and returns the new time. This sets the cursor position in the profiler views.</summary>
				public const string moveCursor = "ak.wwise.core.profiler.moveCursor";
				/// <summary>Registers a bus, an aux bus or device to receive meter data. Only the Main Audio Bus is registered by default. Use \ref ak_wwise_core_profiler_getmeters to retrieve the meter data after registering. Every call to ak.wwise.core.profiler.registerMeter must have a matching call to \ref ak_wwise_core_profiler_unregistermeter.</summary>
				public const string registerMeter = "ak.wwise.core.profiler.registerMeter";
				/// <summary>Saves profiler as a .prof file according to the given file path.</summary>
				public const string saveCapture = "ak.wwise.core.profiler.saveCapture";
				/// <summary>Sets the user time cursor of the profiler to the specified time, in milliseconds, and returns the new time. Use the time obtained from the other profiler functions. Note that the specified time will be snapped to a buffer interval (~10ms). This sets the cursor position in the profiler views. To synchronize the user time cursor to the latest capture time, use \ref ak_wwise_ui_commands_execute with \c ToggleFollowCapture.</summary>
				public const string setCursorTime = "ak.wwise.core.profiler.setCursorTime";
				/// <summary>Starts the profiler capture and returns the time at the beginning of the capture, in milliseconds.</summary>
				public const string startCapture = "ak.wwise.core.profiler.startCapture";
				/// <summary>Sent when a state group state has been changed. This subscription does not require the profiler capture log to be started.</summary>
				public const string stateChanged = "ak.wwise.core.profiler.stateChanged";
				/// <summary>Stops the profiler capture and returns the time at the end of the capture, in milliseconds.</summary>
				public const string stopCapture = "ak.wwise.core.profiler.stopCapture";
				/// <summary>Sent when a switch group state has been changed. This function does not require the profiler capture log to be started.</summary>
				public const string switchChanged = "ak.wwise.core.profiler.switchChanged";
				/// <summary>Unregisters a bus or device that was registered with \ref ak_wwise_core_profiler_registermeter.</summary>
				public const string unregisterMeter = "ak.wwise.core.profiler.unregisterMeter";
			}
			public class project
			{
				/// <summary>Sent when the project has been successfully loaded.</summary>
				public const string loaded = "ak.wwise.core.project.loaded";
				/// <summary>Sent when the after the project is completely closed.</summary>
				public const string postClosed = "ak.wwise.core.project.postClosed";
				/// <summary>Sent when the project begins closing.</summary>
				public const string preClosed = "ak.wwise.core.project.preClosed";
				/// <summary>Saves the current project.</summary>
				public const string save = "ak.wwise.core.project.save";
				/// <summary>Sent when the project has been saved.</summary>
				public const string saved = "ak.wwise.core.project.saved";
			}
			public class remote
			{
				/// <summary>Connects the Wwise Authoring application to a Wwise Sound Engine running executable or to a saved profile file. The host must be running code with communication enabled. If only "host" is provided, Wwise connects to the first Sound Engine instance found. To distinguish between different instances, you can also provide the name of the application to connect to.</summary>
				public const string connect = "ak.wwise.core.remote.connect";
				/// <summary>Disconnects the Wwise Authoring application from a connected Wwise Sound Engine running executable.</summary>
				public const string disconnect = "ak.wwise.core.remote.disconnect";
				/// <summary>Retrieves all consoles available for connecting Wwise Authoring to a Sound Engine instance.</summary>
				public const string getAvailableConsoles = "ak.wwise.core.remote.getAvailableConsoles";
				/// <summary>Retrieves the connection status.</summary>
				public const string getConnectionStatus = "ak.wwise.core.remote.getConnectionStatus";
			}
			public class sound
			{
				/// <summary>Sets which version of the source is being used for the specified sound. Use \ref ak_wwise_core_object_get with the 'activeSource' return option to get the active source of a sound.</summary>
				public const string setActiveSource = "ak.wwise.core.sound.setActiveSource";
			}
			public class soundbank
			{
				/// <summary>Converts the external sources files for the project as detailed in the wsources file, and places them into either the default folder, or the folder specified by the output argument. External Sources are a special type of source that you can put in a Sound object in Wwise. It indicates that the real sound data will be provided at run time. While External Source conversion is also triggered by SoundBank generation, this operation can be used to process sources not contained in the Wwise Project. Please see Wwise SDK help page "Integrating External Sources".</summary>
				public const string convertExternalSources = "ak.wwise.core.soundbank.convertExternalSources";
				/// <summary>Generate a list of SoundBanks with the import definition specified in the WAAPI request. If you do not write the SoundBanks to disk, subscribe to \ref ak_wwise_core_soundbank_generated to receive SoundBank structure info and the bank data as base64. Note: This is a synchronous operation.</summary>
				public const string generate = "ak.wwise.core.soundbank.generate";
				/// <summary>Sent when a single SoundBank is generated. This could be sent multiple times during SoundBank generation, for every SoundBank generated and for every platform. To generate SoundBanks, see \ref ak_wwise_core_soundbank_generate or \ref ak_wwise_ui_commands_execute with one of the SoundBank generation commands. See \ref globalcommandsids for the list of commands.</summary>
				public const string generated = "ak.wwise.core.soundbank.generated";
				/// <summary>Sent when all SoundBanks are generated. Note: This notification is only sent when SoundBanks have been generated, it is not a reliable way to determine when \ref ak_wwise_core_soundbank_generate has completed.</summary>
				public const string generationDone = "ak.wwise.core.soundbank.generationDone";
				/// <summary>Retrieves a SoundBank's inclusion list.</summary>
				public const string getInclusions = "ak.wwise.core.soundbank.getInclusions";
				/// <summary>Imports SoundBank definitions from the specified file. Multiple files can be specified. See the WAAPI log for status messages.</summary>
				public const string processDefinitionFiles = "ak.wwise.core.soundbank.processDefinitionFiles";
				/// <summary>Modifies a SoundBank's inclusion list. The 'operation' argument determines how the 'inclusions' argument modifies the SoundBank's inclusion list; 'inclusions' may be added to / removed from / replace the SoundBank's inclusion list.</summary>
				public const string setInclusions = "ak.wwise.core.soundbank.setInclusions";
			}
			public class sourceControl
			{
				/// <summary>Add files to source control. Equivalent to Mark for Add for Perforce.</summary>
				public const string add = "ak.wwise.core.sourceControl.add";
				/// <summary>Check out files from source control. Equivalent to Check Out for Perforce.</summary>
				public const string checkOut = "ak.wwise.core.sourceControl.checkOut";
				/// <summary>Commit files to source control. Equivalent to Submit Changes for Perforce.</summary>
				public const string commit = "ak.wwise.core.sourceControl.commit";
				/// <summary>Delete files from source control. Equivalent to Mark for Delete for Perforce.</summary>
				public const string delete = "ak.wwise.core.sourceControl.delete";
				/// <summary>Retrieve all original files.</summary>
				public const string getSourceFiles = "ak.wwise.core.sourceControl.getSourceFiles";
				/// <summary>Get the source control status of the specified files.</summary>
				public const string getStatus = "ak.wwise.core.sourceControl.getStatus";
				/// <summary>Move or rename files in source control. Always pass the same number of elements in files and newFiles. Equivalent to Move for Perforce.</summary>
				public const string move = "ak.wwise.core.sourceControl.move";
				/// <summary>Revert changes to files in source control.</summary>
				public const string revert = "ak.wwise.core.sourceControl.revert";
				/// <summary>Change the source control provider and credentials. This is the same setting as the Source Control option in the Project Settings dialog in Wwise.</summary>
				public const string setProvider = "ak.wwise.core.sourceControl.setProvider";
			}
			public class switchContainer
			{
				/// <summary>Assigns a Switch Container's child to a Switch. This is the equivalent of doing a drag&drop of the child to a state in the Assigned Objects view. The child is always added at the end for each state.</summary>
				public const string addAssignment = "ak.wwise.core.switchContainer.addAssignment";
				/// <summary>Sent when an assignment is added to a Switch Container.</summary>
				public const string assignmentAdded = "ak.wwise.core.switchContainer.assignmentAdded";
				/// <summary>Sent when an assignment is removed from a Switch Container.</summary>
				public const string assignmentRemoved = "ak.wwise.core.switchContainer.assignmentRemoved";
				/// <summary>Returns the list of assignments between a Switch Container's children and states.</summary>
				public const string getAssignments = "ak.wwise.core.switchContainer.getAssignments";
				/// <summary>Removes an assignment between a Switch Container's child and a State.</summary>
				public const string removeAssignment = "ak.wwise.core.switchContainer.removeAssignment";
			}
			public class transport
			{
				/// <summary>Creates a transport object for the given Wwise object. The return transport object can be used to play, stop, pause and resume the Wwise object via the other transport functions.</summary>
				public const string create = "ak.wwise.core.transport.create";
				/// <summary>Destroys the given transport object.</summary>
				public const string destroy = "ak.wwise.core.transport.destroy";
				/// <summary>Executes an action on the given transport object, or all transport objects if none is specified.</summary>
				public const string executeAction = "ak.wwise.core.transport.executeAction";
				/// <summary>Returns the list of transport objects.</summary>
				public const string getList = "ak.wwise.core.transport.getList";
				/// <summary>Gets the state of the given transport object.</summary>
				public const string getState = "ak.wwise.core.transport.getState";
				/// <summary>Prepare the object and its dependencies for playback. Use this function before calling PostEventSync or PostMIDIOnEventSync from IAkGlobalPluginContext.</summary>
				public const string prepare = "ak.wwise.core.transport.prepare";
				/// <summary>Sent when the transport's state has changed.</summary>
				public const string stateChanged = "ak.wwise.core.transport.stateChanged";
				/// <summary>Sets the Original/Converted transport toggle globally. This allows playing the original or the converted sound files.</summary>
				public const string useOriginals = "ak.wwise.core.transport.useOriginals";
			}
			public class undo
			{
				/// <summary>Begins an undo group. Make sure to call \ref ak_wwise_core_undo_endgroup exactly once for every ak.wwise.core.beginUndoGroup call you make. Calls to ak.wwise.core.undo.beginGroup can be nested. When closing a WAMP session, a check is made to ensure that all undo groups are closed. If not, a cancelGroup is called for each of the groups still open.</summary>
				public const string beginGroup = "ak.wwise.core.undo.beginGroup";
				/// <summary>Cancels the last undo group.</summary>
				public const string cancelGroup = "ak.wwise.core.undo.cancelGroup";
				/// <summary>Ends the last undo group.</summary>
				public const string endGroup = "ak.wwise.core.undo.endGroup";
				/// <summary>Redoes the last operation in the Undo stack.</summary>
				public const string redo = "ak.wwise.core.undo.redo";
				/// <summary>Undoes the last operation in the Undo stack.</summary>
				public const string undo_ = "ak.wwise.core.undo.undo";
			}
			public class workUnit
			{
				/// <summary>Load a Work Unit that was previously unloaded. The Undo history will be cleared.</summary>
				public const string load = "ak.wwise.core.workUnit.load";
				/// <summary>Unload a Work Unit. No object contained in the Work Unit will be available after this call. If the Work Unit is modified and not saved, the function will return error. The Undo history will be cleared.</summary>
				public const string unload = "ak.wwise.core.workUnit.unload";
			}
		}
		public class debug
		{
			/// <summary>Sent when an assert has failed. This is only available in Debug builds.</summary>
			public const string assertFailed = "ak.wwise.debug.assertFailed";
			/// <summary>Enables debug assertions. Every call to enableAsserts with 'false' increments the ref count. Calling with true decrements the ref count. This is only available with Debug builds.</summary>
			public const string enableAsserts = "ak.wwise.debug.enableAsserts";
			/// <summary>Enables or disables the automation mode for Wwise. This reduces the potential interruptions caused by message boxes and dialogs. For instance, enabling the automation mode silently accepts: project migration, project load log, EULA acceptance, project licence display and generic message boxes.</summary>
			public const string enableAutomationMode = "ak.wwise.debug.enableAutomationMode";
			/// <summary>Generate a WAV file playing a tone with a simple envelope and save it to the specified location. This is provided as a utility to generate test WAV files.</summary>
			public const string generateToneWAV = "ak.wwise.debug.generateToneWAV";
			/// <summary>Retrieves the WAL tree, which describes the nodes that are synchronized in the Sound Engine. Private use only.</summary>
			public const string getWalTree = "ak.wwise.debug.getWalTree";
			/// <summary>Restart WAAPI servers. For internal use only.</summary>
			public const string restartWaapiServers = "ak.wwise.debug.restartWaapiServers";
			/// <summary>Private use only.</summary>
			public const string testAssert = "ak.wwise.debug.testAssert";
			/// <summary>Private use only.</summary>
			public const string testCrash = "ak.wwise.debug.testCrash";
			/// <summary>Validate the arguments, options and result of a WAAPI function call. Does not actually call the function. This is only available with Debug builds.</summary>
			public const string validateCall = "ak.wwise.debug.validateCall";
		}
		public class ui
		{
			/// <summary>Bring Wwise main window to foreground. See SetForegroundWindow and AllowSetForegroundWindow on MSDN for more information on the restrictions. See ak.wwise.core.getInfo to obtain the Wwise process ID for AllowSetForegroundWindow.</summary>
			public const string bringToForeground = "ak.wwise.ui.bringToForeground";
			/// <summary>Captures a part of the Wwise UI relative to a view.</summary>
			public const string captureScreen = "ak.wwise.ui.captureScreen";
			public class cli
			{
				/// <summary>Execute a Lua script. Optionally, specify additional Lua search paths, additional modules, and additional Lua scripts to load prior to the main script. The script can return a value. All arguments will be passed to the Lua script in the "wa_args" global variable.</summary>
				public const string executeLuaScript = "ak.wwise.ui.cli.executeLuaScript";
				/// <summary>Launch the main window of WwiseXP.</summary>
				public const string launch = "ak.wwise.ui.cli.launch";
			}
			public class commands
			{
				/// <summary>Executes a command. Some commands can take a list of objects as parameters. See \ref globalcommandsids for the available commands.</summary>
				public const string execute = "ak.wwise.ui.commands.execute";
				/// <summary>Sent when a command is executed. The objects for which the command is executed are sent in the publication.</summary>
				public const string executed = "ak.wwise.ui.commands.executed";
				/// <summary>Gets the list of commands.</summary>
				public const string getCommands = "ak.wwise.ui.commands.getCommands";
				/// <summary>Registers an array of add-on commands. Registered commands remain until the Wwise process is terminated. See \ref defining_custom_commands for more information about registering commands. Also see \ref ak_wwise_ui_commands_executed.</summary>
				public const string register = "ak.wwise.ui.commands.register";
				/// <summary>Unregisters an array of add-on UI commands.</summary>
				public const string unregister = "ak.wwise.ui.commands.unregister";
			}
			/// <summary>Retrieves the list of files currently selected by the user in the active view. Note that this function is not available in WwiseConsole.</summary>
			public const string getSelectedFiles = "ak.wwise.ui.getSelectedFiles";
			/// <summary>Retrieves the list of objects currently selected by the user in the active view. Note that this function is not available in WwiseConsole.</summary>
			public const string getSelectedObjects = "ak.wwise.ui.getSelectedObjects";
			public class layout
			{
				/// <summary>Requests to close a view by its unique id. The view might not yet be closed when returning from this function.</summary>
				public const string closeView = "ak.wwise.ui.layout.closeView";
				/// <summary>Dock a floating view into a layout.</summary>
				public const string dockView = "ak.wwise.ui.layout.dockView";
				/// <summary>Retrieves the current layout name.</summary>
				public const string getCurrentLayoutName = "ak.wwise.ui.layout.getCurrentLayoutName";
				/// <summary>Retrieves the current allocated rectangle of a layout element. An empty rect is returned if the element is not found.</summary>
				public const string getElementRectangle = "ak.wwise.ui.layout.getElementRectangle";
				/// <summary>Serializes a specific layout into a JSON format.</summary>
				public const string getLayout = "ak.wwise.ui.layout.getLayout";
				/// <summary>Retrieves a list of the factory layout names.</summary>
				public const string getLayoutNames = "ak.wwise.ui.layout.getLayoutNames";
				/// <summary>Gets a view, if it exists in the current layout, or creates a new one.</summary>
				public const string getOrCreateView = "ak.wwise.ui.layout.getOrCreateView";
				/// <summary>Gets the frontend handle of an instantiated view.</summary>
				public const string getViewHandle = "ak.wwise.ui.layout.getViewHandle";
				/// <summary>Retrieves a list of all view instances of a layout.</summary>
				public const string getViewInstances = "ak.wwise.ui.layout.getViewInstances";
				/// <summary>Retrieves a list of all view types registered in Wwise.</summary>
				public const string getViewTypes = "ak.wwise.ui.layout.getViewTypes";
				/// <summary>Moves a splitter by a delta given in pixels.</summary>
				public const string moveSplitter = "ak.wwise.ui.layout.moveSplitter";
				/// <summary>Unregisters a temporary layout, previously registered with \ref ak_wwise_ui_layout_setlayout.</summary>
				public const string removeLayout = "ak.wwise.ui.layout.removeLayout";
				/// <summary>Reset layouts to their default state.</summary>
				public const string resetLayouts = "ak.wwise.ui.layout.resetLayouts";
				/// <summary>Registers a new layout from a JSON format.</summary>
				public const string setLayout = "ak.wwise.ui.layout.setLayout";
				/// <summary>Switches the current layout.</summary>
				public const string switchLayout = "ak.wwise.ui.layout.switchLayout";
				/// <summary>Undock a view from a layout.</summary>
				public const string undockView = "ak.wwise.ui.layout.undockView";
			}
			public class model
			{
				/// <summary>Creates a frontend handle and instantiates its widgets.</summary>
				public const string createHandle = "ak.wwise.ui.model.createHandle";
				/// <summary>Destroys a frontend handle and its widgets.</summary>
				public const string destroyHandle = "ak.wwise.ui.model.destroyHandle";
				/// <summary>Gets the state of widgets.</summary>
				public const string getState = "ak.wwise.ui.model.getState";
				/// <summary>Registers WAFM files and inline widget descriptors.</summary>
				public const string registerWafm = "ak.wwise.ui.model.registerWafm";
				/// <summary>Sets the state of widgets.</summary>
				public const string setState = "ak.wwise.ui.model.setState";
			}
			public class project
			{
				/// <summary>Closes the current project.</summary>
				public const string close = "ak.wwise.ui.project.close";
				/// <summary>Creates, saves and opens new empty project, specified by path and platform. The project has no factory setting WorkUnit.  Please see \ref ak_wwise_core_project_loaded for further explanations on how to be notified when the operation has completed.</summary>
				public const string create = "ak.wwise.ui.project.create";
				/// <summary>Opens a project, specified by path. Please see \ref ak_wwise_core_project_loaded for further explanations on how to be notified when the operation has completed.</summary>
				public const string open = "ak.wwise.ui.project.open";
			}
			/// <summary>Sent when the selection changes in the project.</summary>
			public const string selectionChanged = "ak.wwise.ui.selectionChanged";
			public class signal
			{
				/// <summary>Emitted when a push button or a radio button gets clicked.</summary>
				public const string click = "ak.wwise.ui.signal.click";
				/// <summary>Emits a signal on a widget.</summary>
				public const string emit = "ak.wwise.ui.signal.emit";
				/// <summary>Emitted when a toggle button or a checkbox gets toggled.</summary>
				public const string toggle = "ak.wwise.ui.signal.toggle";
			}
			public class window
			{
				/// <summary>Closes a window and unrealizes its widgets.</summary>
				public const string close = "ak.wwise.ui.window.close";
				/// <summary>Creates a window in which a frontend handle can be instantiated.</summary>
				public const string create = "ak.wwise.ui.window.create";
				/// <summary>Presents a window and realizes its widgets.</summary>
				public const string present = "ak.wwise.ui.window.present";
			}
		}
		public class waapi
		{
			/// <summary>Retrieves the list of functions.</summary>
			public const string getFunctions = "ak.wwise.waapi.getFunctions";
			/// <summary>Retrieves the JSON schema of a Waapi Function or Topic URI.</summary>
			public const string getSchema = "ak.wwise.waapi.getSchema";
			/// <summary>Retrieves the list of topics to which a client can subscribe.</summary>
			public const string getTopics = "ak.wwise.waapi.getTopics";
		}
	}
}
