/*******************************************************************************
The content of this file includes portions of the AUDIOKINETIC Wwise Technology
released in source code form as part of the SDK installer package.

Commercial License Usage

Licensees holding valid commercial licenses to the AUDIOKINETIC Wwise Technology
may use this file in accordance with the end user license agreement provided
with the software or, alternatively, in accordance with the terms contained in a
written agreement between you and Audiokinetic Inc.

Apache License Usage

Alternatively, this file may be used under the Apache License, Version 2.0 (the
"Apache License"); you may not use this file except in compliance with the
Apache License. You may obtain a copy of the Apache License at
http://www.apache.org/licenses/LICENSE-2.0.

Unless required by applicable law or agreed to in writing, software distributed
under the Apache License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES
OR CONDITIONS OF ANY KIND, either express or implied. See the Apache License for
the specific language governing permissions and limitations under the License.

  Copyright (c) 2026 Audiokinetic Inc.
*******************************************************************************/

#pragma once

#include <AK/SoundEngine/Common/AkCommonDefs.h>

namespace AK
{
	namespace ProfilingID
	{
		enum ProfilingID
		{
			AudioFrameBoundary = 1,
			AudioVoiceStarvation,
			CAkLEngine_AnalyzeMixingGraph,
			CAkLEngine_PreprocessSources,
			CAkLEngine_VoiceTask,
			CAkLEngine_VoiceTaskParallelAsync,
			AkPerf_PostPipelineStats,
			CommunicationCentral_Process,
			JobMgr_WorkerFunction,
			SwVoice,
			HwVoice,
			BusTask,
			CheckValidSamples,
			SpatialAudio_Update,
			SpatialAudio_Dispatch,
			SpatialAudio_End,
			SpatialAudio_EndRender,
			SpatialAudio_EmitterToListener,
			SpatialAudio_ClusterFollower,
			SpatialAudio_ClusterPortalFollower,
			SpatialAudio_ReflectionGathering,
			SpatialAudio_ReflectionValidation,
			SpatialAudio_ListenerRayCasting,
			SpatialAudio_Clustering,
			SpatialAudio_ListenerToPortal,
			SpatialAudio_EmitterToPortal,
			SpatialAudio_PortalToPortal,
			SpatialAudio_PortalRayCasting,
			SpatialAudio_IndirectPathsAndSends,
			CAkEdgePathSearch_Search,
			CAkStochasticReflectionEngine_ComputeRays,
			CAkStochasticReflectionEngine_TraceDiffractionRay,
			CAkStochasticReflectionEngine_TraceReflectionRay,
			CAkStochasticReflectionEngine_ValidateExistingPaths,
			CAkStochasticReflectionEngine_ValidatePaths,
			CAkStochasticReflectionEngine_ValidateReflectionPaths,
			CAkStochasticReflectionEngine_ValidateDiffractionPaths,
			CAkStochasticReflectionEngine_ClearRays,
			AkStochasticReflectionEngine_SortPaths,
			AkAcousticRoom_PropagateSound,
			AkAcousticRoom_Update,
			AkSoundGeometry_SetGeometry,
			AkSoundGeometry_SetGeometryInstance,
			IODevice_TaskUpdate,
			IODevice_BatchOpen,
			IODevice_BatchRead,
			IODevice_BatchWrite,
			CAkLEngine_DispatchBusGraphAsync,
			AkSoundGeometry_GetOverlapRooms,
			AkSoundGeometry_ComputeSignedDistance,
			SpatialAudio_RoomPreProcess,

			Num // Keep last!
		};

		enum MetaID
		{
			PipelineID = Num // Avoid ID space clash
		};

#ifdef AK_IMPLEMENT_PROFILINGID_NAMES
		const char* s_aszNames[] =
		{
			"AK INVALID PROFILEID", // should never be used; 0 means no relevant profile id was provided
			"AK Audio Frame Boundary",
			"AK Audio Voice Starvation",
			"CAkLEngine::AnalyzeMixingGraph",
			"CAkLEngine::PreprocessSources",
			"CAkLEngine::VoiceTask",
			"CAkLEngine::VoiceTaskParallelAsync",
			"AkPerf::PostPipelineStats",
			"AK::CommunicationCentral::Process",
			"AkJobMgr::WorkerFunction",
			"AK SwVoice",
			"AK HwVoice",
			"AK BusTask",
			"AK CheckValidSamples",
			"AK::SpatialAudio::Update",
			"AK::SpatialAudio::Dispatch",
			"AK::SpatialAudio::End",
			"AK::SpatialAudio::EndRender",
			"AK::SpatialAudio::EmitterToListener",
			"AK::SpatialAudio::ClusterFollower",
			"AK::SpatialAudio::ClusterPortalFollower",
			"AK::SpatialAudio::ReflectionGathering",
			"AK::SpatialAudio::ReflectionValidation",
			"AK::SpatialAudio::ListenerRayCasting",
			"AK::SpatialAudio::Clustering",
			"AK::SpatialAudio::ListenerToPortal",
			"AK::SpatialAudio::EmitterToPortal",
			"AK::SpatialAudio::PortalToPortal",
			"AK::SpatialAudio::PortalRayCasting",
			"AK::SpatialAudio::IndirectPathsAndSends",
			"CAkEdgePathSearch::Search",
			"CAkStochasticReflectionEngine::ComputeRays",
			"CAkStochasticReflectionEngine::TraceDiffractionRay",
			"CAkStochasticReflectionEngine::TraceReflectionRay",
			"CAkStochasticReflectionEngine::ValidateExistingPaths",
			"CAkStochasticReflectionEngine::ValidatePaths",
			"CAkStochasticReflectionEngine::ValidateReflectionPaths",
			"CAkStochasticReflectionEngine::ValidateDiffractionPaths",
			"CAkStochasticReflectionEngine::ClearRays",
			"CAkStochasticReflectionEngine::SortPaths",
			"AkAcousticRoom::PropagateSound",
			"AkAcousticRoom::Update",
			"AkSoundGeometry::SetGeometry",
			"AkSoundGeometry::SetGeometryInstance",
			"AK IODevice TaskUpdate",
			"AK IODevice BatchOpen",
			"AK IODevice BatchRead",
			"AK IODevice BatchWrite",
			"CAkLEngine::DispatchBusGraphAsync",
			"AkSoundGeometry::GetOverlapRooms",
			"AkSoundGeometry::ComputeSignedDistance",
			"AK::SpatialAudio::RoomPreProcess",

		};

		static_assert((sizeof(s_aszNames) / sizeof(s_aszNames[0])) == AK::ProfilingID::Num, "ARRAYSIZE(AK::ProfilingID::s_aszNames) is not matching AK::ProfilingID::Num, make sure they are maintained at the same time.");
#endif
	}
}

#define AKMAKECLASSIDFORPROFILING( _profilingid_ ) AKMAKECLASSID( AkPluginTypeNone, AKCOMPANYID_AUDIOKINETIC, _profilingid_ )
