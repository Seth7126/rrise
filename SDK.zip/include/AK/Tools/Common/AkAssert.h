/*******************************************************************************
The content of this file includes portions of the AUDIOKINETIC Wwise Technology
released in source code form as part of the SDK installer package.

Commercial License Usage

Licensees holding valid commercial licenses to the AUDIOKINETIC Wwise Technology
may use this file in accordance with the end user license agreement provided 
with the software or, alternatively, in accordance with the terms contained in a
written agreement between you and Audiokinetic Inc.

Apache License Usage

Alternatively, this file may be used under the Apache License, Version 2.0 (the 
"Apache License"); you may not use this file except in compliance with the 
Apache License. You may obtain a copy of the Apache License at 
http://www.apache.org/licenses/LICENSE-2.0.

Unless required by applicable law or agreed to in writing, software distributed
under the Apache License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES
OR CONDITIONS OF ANY KIND, either express or implied. See the Apache License for
the specific language governing permissions and limitations under the License.

  Copyright (c) 2026 Audiokinetic Inc.
*******************************************************************************/

#ifndef _AK_AKASSERT_H_
#define _AK_AKASSERT_H_

#if defined( _DEBUG ) && !(defined AK_DISABLE_ASSERTS)
	#ifndef AK_ENABLE_ASSERTS
		#define AK_ENABLE_ASSERTS
	#endif
#endif

#ifdef AK_ENABLE_ASSERTS
	#include <AK/SoundEngine/Common/AkSoundEngineExport.h>
	#ifndef AK_ASSERT_HOOK
		AK_CALLBACK( void, AkAssertHook)( 
								const char * in_pszExpression,	///< Expression
								const char * in_pszFileName,	///< File Name
								int in_lineNumber				///< Line Number
								);
		#define AK_ASSERT_HOOK
	#endif

	extern "C" AK_DLLEXPORT AkAssertHook g_pAssertHook;
#endif

#if !defined( AKASSERT )
	#include <AK/SoundEngine/Common/AkTypes.h> //For AK_Fail/Success

	#if defined( AK_ENABLE_ASSERTS )
		// These platforms use a built-in g_pAssertHook (and do not fall back to the regular assert macro)
		#define AKASSERT(Condition) if AK_EXPECT_FALSE( g_pAssertHook != nullptr && !(Condition)) { g_pAssertHook( #Condition, __FILE__, __LINE__); }

		#define AKVERIFY(Condition) (!(Condition) && g_pAssertHook != nullptr ? g_pAssertHook( #Condition, __FILE__, __LINE__) : ((void) 0) )

		#define AK_IS_ASSERT_HOOKED (g_pAssertHook != nullptr)

		#ifdef _DEBUG
			#define AKASSERTD AKASSERT
		#else
			#define AKASSERTD(Condition) ((void)0)
		#endif

	#else //  defined( AK_ENABLE_ASSERTS )

		#define AKASSERT(Condition) do { switch ( 0 ) { case 0: break; default: if ( !( Condition ) ) {} } } while ( 0 )

		#define AKVERIFY(x) ((void)(x))

		#define AK_IS_ASSERT_HOOKED (false)

		#ifdef _DEBUG
			#define AKASSERTD AKASSERT
		#else
			#define AKASSERTD(Condition) ((void)0)
		#endif

	#endif //  defined( AK_ENABLE_ASSERTS )

	#define AKASSERT_RANGE(Value, Min, Max) (AKASSERT(((Value) >= (Min)) && ((Value) <= (Max))))

	#define AKASSERTANDRETURN( __Expression, __ErrorCode )\
		if (!(__Expression))\
		{\
			AKASSERT(__Expression);\
			return __ErrorCode;\
		}\

	#define AKASSERTPOINTERORFAIL( __Pointer ) AKASSERTANDRETURN( __Pointer != NULL, AK_Fail )
	#define AKASSERTSUCCESSORRETURN( __akr ) AKASSERTANDRETURN( __akr == AK_Success, __akr )

	#define AKASSERTPOINTERORRETURN( __Pointer ) \
		if ((__Pointer) == NULL)\
		{\
			AKASSERT((__Pointer) == NULL);\
			return ;\
		}\

	#if defined( AK_WIN ) && ( _MSC_VER >= 1600 )
		// Compile-time assert
		#define AKSTATICASSERT( __expr__, __msg__ ) static_assert( (__expr__), (__msg__) )
	#else
		// Compile-time assert
		#define AKSTATICASSERT( __expr__, __msg__ ) typedef char __AKSTATICASSERT__[(__expr__)?1:-1]
	#endif	

#endif // ! defined( AKASSERT )

#endif