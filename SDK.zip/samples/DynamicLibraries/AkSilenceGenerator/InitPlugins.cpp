#include <AK/SoundEngine/Common/IAkPlugin.h>
#include <AK/Plugin/AkSilenceSourceFactory.h>
DEFINE_PLUGIN_REGISTER_HOOK

DEFINE_PLUGIN_ASSERT_HOOK